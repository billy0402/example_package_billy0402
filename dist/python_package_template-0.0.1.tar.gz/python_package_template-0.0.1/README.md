# python-package-template

## environment

- [macOS 12.6.5](https://www.apple.com/tw/macos/monterey/)
- [Visual Studio Code 1.77.0](https://code.visualstudio.com/)
- [Python 3.10.5](https://www.python.org/)

## official tutorial

- [https://packaging.python.org/en/latest/tutorials/packaging-projects/](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.
